Cs 251
Group19
LAB 10 INLAB

group members :
1) Naveen Kumar (140050013) : 100%
2) Yathansh Kathuria (140050021) : 100%
3) Rajat Chaturvedi (140050027) : 100%

Observations:
Q1)
Error:
controlPanel was used before defining it.(it was not defined)

Correction:
we defined controlPanel= new JPanel()

Output:
I am a basic GUI!!

Honour Code:
I pledge on my honour that I have not recieved or given any unauthorised assistance in this or any other previous task.
			- Naveen Kumar

I pledge on my honour that I have not recieved or given any unauthorised assistance in this or any other previous task.
			-yathansh kathuria

I pledge on my honour that I have not recieved or given any unauthorised assistance in this or any other previous task.
			- Rajat Chaturvedi


Citations:
1)javatpoint.com
2)tutorialspoint.com
3)stackoverflow.com
4)docs.oracle.org
5)alvinalaxender.com
6)piazza.com
