touch sshX[1,2].dat
>sshX[1,2].dat
ping -n -i 0.30 -c 50 nsl-64 >> temp.dat;
a1='='
FILE=temp.dat;
i=1
while read LINE  
do 
	if [[ $LINE == *time=* ]] ; then
			ini=${LINE:0:1}
			LINE=${LINE##$ini*$a1}
			fin=${LINE: -1}
			LINE=${LINE%$b1*$fin}
			echo $LINE $i | tr -d 'm' >> sshX[1,2].dat
			i=$[i+1]
		
	fi

done <$FILE 
rm temp.dat

