#!/usr/bin/gnuplot
 set xrange [0:4]
set term png
set output "boxWhisker.png"
set bars 2.0
 set style fill empty
 plot 'data.dat' using 1:3:2:6:5:xticlabels(7) with candlesticks title 'Ping times' whiskerbars, \
    ''         using 1:4:4:4:4 with candlesticks lt -1 notitle
