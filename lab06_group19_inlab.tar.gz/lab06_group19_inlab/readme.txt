CS 251
LAB06 INLAB
Gropu 19
inficoders

Group Members:
140050013, Naveen Kumar
140050021, Yathansh Kathuria
140050027, Rajat Chaturvedi

Contribution:
Naveen Kumar(140050013): 100%
Yathansh Kathuria(140050021): 100%
Rajat Chaturvedi(140050027): 100%


Honour code

I pledge on my honour that I have not given or received any unauthorized assistance on this or any other previous assignment.
											-Naveen Kumar
I pledge on my honour that I have not given or received any unauthorized assistance on this or any other previous assignment.
		                                				   -Yathansh Kathuria
I pledge on my honour that I have not given or received any unauthorized assistance on this or any other previous assignment.
										     -Rajat Chaturvedi


Citations :
1) stackoverflow.com
2) gnuplot.stackexchange.com
3) www.sharelatex.com
4) xelatex.org
5) tex.stackexchange.com
6) piazza.com
7) gnuplot.org
8) gnuplotting.org
9) math.utk.edu
10) lexilogos.com
11) wikipedia.org

Thanks to the Professor and the TAs for their guidance and help.

