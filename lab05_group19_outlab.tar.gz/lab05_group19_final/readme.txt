CS 251
LAB 05 OUTLAB
GROUP 19
INFICODERS

Group Members:
1) Naveen Kumar,140050013
2) Yathansh Kathuria, 140050021
3) Rajat Chaturvedi, 140050027

Individual Contributions:
1) Naveen Kumar : 100%
2) Yathansh Kathuria : 100%
3) Rajat Chaturvedi : 100%

Instructions:
1. the answers to the theory question is provided in the make.txt file .
   for running the makefile:
	the given makefile is named as makefile_g19.
	change the name to makefile.
	and put in the directory of cs251_base_code.
	command:
	cd [cs251_base_code directory]
	make

	for cleaning files:
	make clean

	for cleaning files and folders and return to initial state
	make distclean

We have used the makefile provided by the sir along with cs251_base_code and modified accordingly.The colors of text is as written as by sir.

2. for cmake instructions
	put the CMakeLists.txt file provided in the square_and_add folder.
	cd [location of square_and_add directory]/build
	cmake ..
	make




Honor Code:

I pledge on my honor that I have not given or received any unathorized help in this or any other previous assignments.
											- Naveen Kumar


I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Yathansh Kathuria


I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Rajat Chaturvedi


Citations:

1) cmake.org
2) derekmolloy.ie
3) stackoverflow.com
4) csfundamentals.com
5) vtk.org
6) wikipidea.org
7) courses.cms.caltech.edu/cs11/material
8) kitware.com
9) tdlp.org
10) linux.die.net
11) askubuntu.com
12) piazza.com

special thanks to instructor and TAs for guidance.









