import java.util.*;
import java.io.*;
import java.net.*;
public class JServer
{
	public ServerSocket serversocket;
	public Socket socket;
	public BufferedReader keyRead;
	public BufferedReader receiveRead;
	public PrintWriter pwrite;
	public JChatComm jchatcomm;	
	public String s;
	public JMessage jmessage;


	public JServer() throws IOException
	{
		System.out.println("Waiting for a client to connect ... ");
		serversocket = new ServerSocket(5123);
	      	socket = serversocket.accept();
		
	}
	
	public void sendMessage() throws IOException
	{
		keyRead = new BufferedReader(new InputStreamReader(System.in));
	                      // sending to client (pwrite object)
      		OutputStream ostream = socket.getOutputStream(); 
      		pwrite = new PrintWriter(ostream, true);

	}	
	
	public void receiveMessage() throws IOException
	{
		InputStream istream = socket.getInputStream();
     		receiveRead = new BufferedReader(new InputStreamReader(istream));

	}	
	
  	public void acceptConnection() throws IOException
 	{
        	sendMessage();
                receiveMessage();
      		String receiveMessage, sendMessage; 
		boolean bb=true;   
		Date date;           
      		while(bb=true)
      		{
			
        		if((receiveMessage = receiveRead.readLine()) != "127.0.0.1 : End Chat")  
        		{
           		System.out.println(receiveMessage);  
			date = new Date();System.out.println("  <Received at: "+date.toString()+" >");System.out.println("");       
        		}         
			String sss="127.0.0.1 : End Chat";
			if(sss.equals(receiveMessage)){bb=false;}
			if(bb==false){System.out.println("Connection with client closed"); JServer jserver = new JServer();jserver.acceptConnection();}
			else{
			System.out.print("Me: ");
        		sendMessage = keyRead.readLine();
			date = new Date();System.out.println("  <Sent at: "+date.toString()+" >");System.out.println("");
			jmessage = new JMessage(sendMessage); 
        		pwrite.println(sendMessage);             
        		pwrite.flush();}
			
      		}               
    	}  
	                
}                        
