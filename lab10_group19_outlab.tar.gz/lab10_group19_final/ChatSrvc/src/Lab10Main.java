import java.net.*;
import java.io.*;
import java.util.*;

public class Lab10Main extends Thread
{
	public static void main(String[] args) throws IOException
	{
		
	        Scanner in = new Scanner(System.in);
		
	        int qqqq=Integer.parseInt(args[0]);
	        while(qqqq==-1)
	        {
	        	qqqq=in.nextInt();
	        	if(qqqq==0) System.out.println("Running as a Server...");
	        	else if(qqqq==1) System.out.println("Running as a Client...");
	        	else 
	       		{
	       			System.out.println("Invalid Input");
	       			qqqq=-1;
	        		System.out.println("Press 0 to run as Server and 1 for Client...");
	        	}
	        }
		if(qqqq==0)
		{
			try{
			JServer j=new JServer();		
			j.acceptConnection();}
			catch(IOException IoE){}
			
		}
		else
		{
			try{
			System.out.println("Give address of server");
			Scanner ins=new Scanner(System.in);
			String s=ins.nextLine();
			JClient j=new JClient(s);		
			j.callServer();}
			catch(IOException IoE){}
		}

	}
}
