import java.net.*;
import java.io.*;
import java.util.*;

public class JPacket
{
	public String message;
	public String time;
}
