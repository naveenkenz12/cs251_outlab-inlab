import java.io.*;
import java.net.*;
import java.util.*;
public class JMessage 
{
	public String message;
	
	JMessage(String message) throws IOException
	{
		this.message=message;		
	}
}
