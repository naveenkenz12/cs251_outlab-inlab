import java.io.*;
import java.net.*;
import java.math.*;
import java.util.concurrent.TimeUnit;
import java.util.*;
public class JClient
{
	public String s;
	public Socket socket;
	public BufferedReader keyRead;
	public BufferedReader receiveRead;
	public PrintWriter pwrite;
	public JChatComm jchatcomm=new JChatComm();
	public JServer jserver;
	public String receiveMessage, sendMessage;
	public JMessage jmessage;
	//public SimpleDateFormat sdf;
		

	public JClient(String s) throws IOException
	{
		System.out.println("Trying to connect to a server ... ");
		this.s=s;
		try{
		TimeUnit.SECONDS.sleep((int)(Math.random()*10));}
		catch(InterruptedException IoE){System.out.println("Server Not Found.");}
		socket = new Socket(s,5123);
		System.out.println("Connected to server : "+s);
		System.out.println("Streams established. Ready for a chat ...");
		System.out.println("");
	}

	public void sendMessage() throws IOException
	{
		keyRead = new BufferedReader(new InputStreamReader(System.in));
      		OutputStream ostream = socket.getOutputStream(); 
      		pwrite = new PrintWriter(ostream, true);

	}	
		
	public void receiveMessage() throws IOException
	{
		InputStream istream = socket.getInputStream();
     		receiveRead = new BufferedReader(new InputStreamReader(istream));

	}
	


  	public void callServer() throws IOException
  	{
		sendMessage();
     		receiveMessage();
		int i=0;
     		boolean bb=true;  
		
		Date date;             
     		while(bb==true)
     		{
			System.out.print("Me: ");
       			if(i!=0){sendMessage = keyRead.readLine();date = new Date();System.out.println("  <Sent at: "+date.toString()+" >");System.out.println("");}
			else {sendMessage="Free For a Chat?";System.out.println("Free For a Chat?");date = new Date();System.out.println("  <Sent at: "+date.toString()+" >");System.out.println("");}
			//System.out.println(sendMessage);
			String sss="End Chat";
			if(sendMessage.equals(sss)){bb=false;}
			jmessage = new JMessage(sendMessage); 
        		pwrite.println(s+" : "+sendMessage);
			String ssss="Sure. Let us begin.";
			  if(bb==false){break;}
        		pwrite.flush();          
                        if((receiveMessage = receiveRead.readLine()) != "") 
        		{
            			System.out.println(s+" : "+receiveMessage); 
				date = new Date();System.out.println("  <Received at: "+date.toString()+" >");System.out.println("");
        		}   
			if(i==0 && receiveMessage.equals(ssss)==false){bb=false;} 
			i++      ;
			
         	}               
    	}
	                
}   
