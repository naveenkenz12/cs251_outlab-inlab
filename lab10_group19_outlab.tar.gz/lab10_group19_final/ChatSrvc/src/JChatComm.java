import java.io.*;
import java.net.*;
import java.util.*;
public class JChatComm
{
	public JClient jclient;
	public JServer jserver;
	public Socket socket;

	public void sendMessage() throws IOException
	{
		jclient.keyRead = new BufferedReader(new InputStreamReader(System.in));
	        jserver.keyRead = new BufferedReader(new InputStreamReader(System.in));
      		OutputStream ostream = socket.getOutputStream(); 
      		jclient.pwrite = new PrintWriter(ostream, true);
		jserver.pwrite = new PrintWriter(ostream, true);

	}	
		
	public void receiveMessage() throws IOException
	{
		InputStream istream = socket.getInputStream();
     		jclient.receiveRead = new BufferedReader(new InputStreamReader(istream));
		jserver.receiveRead = new BufferedReader(new InputStreamReader(istream));

	}
	public void endChat() throws IOException
	{

	}

}
