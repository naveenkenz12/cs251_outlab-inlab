CS 251
LAB 10 OUTLAB
GROUP 19
INFICODERS

Group Members:
1) Naveen Kumar,140050013
2) Yathansh Kathuria, 140050021
3) Rajat Chaturvedi, 140050027

Individual Contributions:
1) Naveen Kumar : 100%
2) Yathansh Kathuria : 100%
3) Rajat Chaturvedi : 100%

Instructions:
q1)
line 1 of main.java initially was: System.out.printl("GCD of  numbers is" + gcd_obj.calculateGcd(a,b));
the correct line should be : System.out.println("GCD of  numbers is" + gcd_obj.calculateGcd(a,b));

i.e. printl was to be replaced println to make it correct.

after correction the output is:

Hello world
GCD of numbers is 2
Recursive GCD of numbers is 6
LCM of numbers is 1680.

ChatService:
to start the chat the server must return : "Sure. Let us begin."
any other reply from server wouldnot initiate the chat

relationship bertween the classes:

1)JChatComm:
has 2 functions: sendMessage and receiveMessage- These functions are called from JClient and JServer  to send and receive message

2)Jmessage:
contains the string message to be sent while chatting

3)lab10Main:
calls the Jserver or Jclient depending upon the target user in makefile


Honor Code:

I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Naveen Kumar


I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Yathansh Kathuria


I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Rajat Chaturvedi


Citations:

1)stackexchange.com
2)sanfoundary.com
5)tutorialspoint.com
4)javatpoint.com
5)wikipedi.com
6)piazza.com 
7)takeradar.com
8)gd.tuwien.ac.at
9)cs.swarthmore.edu
10)javadigest.wordpress.com
11)docs.oracle.org
