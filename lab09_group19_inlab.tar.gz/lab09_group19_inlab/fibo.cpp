#include <iostream>
#include<ctime>
using namespace std;

// domain: x >= 0
int fibonacci (int x) {
	if (x <= 1) return x;
	return fibonacci(x-1) + fibonacci(x-2);
	/* (later) think about making this tail recursive */
}

int main (int argc, char* argv[]) {

	clock_t t;
	t=clock();
	if (argc < 2)
		return 1;

	int n = atoi(argv[1]);

	int result= fibonacci(n) ;
	t=clock()-t;
	cout<<n<<","<<result<<","<<((float)t)/CLOCKS_PER_SEC<<"\n";

	return 0;

}
