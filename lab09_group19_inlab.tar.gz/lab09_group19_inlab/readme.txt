CS 251
GROUP 19
LAB09 INLAB


Contribution:
Naveen Kumar(140050013): 100%
Yathansh Kathuria(140050021): 100%
Rajat Chaturvedi(140050027): 100%

Observations:
Q1)
The address of the first three nodes of reverse list are
0x6020d0
0x6020b0
0x602090

Q2)
The primary outputs of bothe commands 'time' and 'usr/bin/time' are wall-clock time, system time and user time.
The values of the wall clock time, which is shown as "real time" in "time", and "elapsed time" in "usr/bin/time". The wall clock time shows the total time taken by to complete the process, and is always greater than the sum of system and user time.

Honour code

I pledge on my honour that I have not given or received any unauthorized assistance on this assignment.
											-Naveen Kumar
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment.
		                                				   -Yathansh Kathuria
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment.
										     -Rajat Chaturvedi

Citations :
1) stackoverflow.com
2) tutorialspoint.com	
3) piazza.com
4) linuxintheshell.com
5) cplusplus.com
6) matplotlib.org
7) pythonprogramming.net


Thanks to the Professor and the TAs for their guidance and help.

