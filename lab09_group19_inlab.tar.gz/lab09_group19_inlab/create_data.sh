#!/bin/bash

touch data.csv
g++ --std=c++0x fibo.cpp
>data.csv
i=1
while [ $i != 47 ]
do
	./a.out $i >> data.csv
	i=$[i+1]	
done	