from matplotlib import pyplot as plt
import numpy as np
cs=np.genfromtxt('data.csv',delimiter=',')
x=cs[:,0]
y1=cs[:,1]
y=cs[:,2]

plt.plot(x,y,label='Time')
plt.title('fibo n vs time')
plt.ylabel('time (in sec)')
plt.xlabel('n')
plt.show()