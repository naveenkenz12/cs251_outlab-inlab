CS251
LAB 05 INLAB
GROUP 19

Group Members:
1) Naveen Kumar, 140050013 : 100%
2) Yathansh Kathuria, 140050021 : 100%
3) Rajat Chaturvedi, 140050027 : 100%


Answer to question 1 (Extra Credits):
->soft links are like shortcuts in windows. when you create a soft link a new node is created which points to are original file.
	can be done using:
		ln -s /usr/bin/gedit ~/Desktop/gedit (to create a soft link of gedit on desktop)
->While creating Hard links no new inode is created and the link directly points to are original file.
-> In both these links any changes made to the original file will cause a change in the link also.

Answer to question 2 (Extra credits):
-> The file dev/zero/ is a special file in linux that provides as many null characters as read from it. In other words it is an infinite stream of null characters (0X00)
-> The file dev/random serves as a blocking pseudonumber generator.IT allows access to environmental noise collected from device drivers and other sources.

Honor Code:

I pledge on my honor that I have not given or received any unauthorized help in this or any other previous tasks.
									-Naveen Kumar


I pledge on my honor that I have not given or received any unauthorized help in this or any other previous tasks.
								-Yathansh Kathuria


I pledge on my honor that I have not given or received any unauthorized help in this or any other previous tasks.
								-Rajat Chaturvedi.


Citations:

1)cycbercity.biz
20superuser.com
3)stackoverflow.com
4)stackexchange.org
5)ubuntuforums.com
6)cmake.org
7)tldp.org
8)piazza.com
9)wikipedia.org

