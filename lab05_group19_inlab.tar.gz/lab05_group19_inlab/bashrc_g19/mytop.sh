#!/bin/bash

watch -n 1 "ps -au | head"