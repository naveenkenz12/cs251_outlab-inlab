CS 251
SOFTWARE SYSTEMS LAB

GROUP 19
inficoders
LAB 03 OUTLAB
(box2D)

GROUP MEMBERS:
(Naveen Kumar,140050013)
(Yathansh Kathuria,140050021)
(Rajat Chaturvedi,140050027)


CONTRIBUTION BY EACH MEMBER:

Naveen Kumar (140050013) : 100% 
Yathansh Kathuria (140050021) : 100% 
Rajat Chaturvedi (140050027) : 100%

Instruction for running:

part 1 and part 2:
1. In both cases replace the existing dominos.cpp file with the file provided alongwith.
2. open terminal.
3. go to directory containing the above folder.
4. run the command make.
5. open bin directory in folder.
6. run the simulation there.




HONOUR CODES:

I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any other previous assignments.

														-Naveen Kumar(140050013)


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

													-Yathansh Kathuria(140050021)


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

													-Rajat Chaturvedi(140050027)


citations:
1. www.box2d.org
2. instruction given in the instruction.txt and readme.txt along with the box2d folder
3. piazza.com
4. www.askubuntu.com for libglui2c2 and libglui-dev packages
5. guidance from instructor and TAs
6. www.stackoverflow.com


Also thanks to the Instructor and classmates on Piazza for alll the help and guidance.
