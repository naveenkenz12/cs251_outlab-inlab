
function displaycontact1(){
    var obj=document.getElementById("contactme");
    obj.style.visibility="visible";
    var obj1=document.getElementById("as1");
    obj1.style.color="red";

}
function revert1(){
    var obj=document.getElementById("contactme");
    obj.style.visibility="hidden";
    var obj1=document.getElementById("as1");
    obj1.style.color="white";
}
function displaycontact2(){
    var obj=document.getElementById("address");
    obj.style.visibility="visible";
    var obj1=document.getElementById("as2");
    obj1.style.color="red";

}
function revert2(){
    var obj=document.getElementById("address");
    obj.style.visibility="hidden";
    var obj1=document.getElementById("as2");
    obj1.style.color="white";
}
function displaycontact3(){
    var obj=document.getElementById("email");
    obj.style.visibility="visible";
    var obj1=document.getElementById("as3");
    obj1.style.color="red";

}
function revert3(){
    var obj=document.getElementById("email");
    obj.style.visibility="hidden";
    var obj1=document.getElementById("as3");
    obj1.style.color="white";
}


function displaycontact5(){
    var obj=document.getElementById("facebook");
    obj.style.visibility="visible";
    var obj1=document.getElementById("as5");
    obj1.style.color="red";

}
function revert5(){
    var obj=document.getElementById("facebook");
    obj.style.visibility="hidden";
    var obj1=document.getElementById("as5");
    obj1.style.color="white";
}
