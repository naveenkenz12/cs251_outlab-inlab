CS 251
SOFTWARE SYSTEMS LAB

GROUP 19
inficoders
LAB 02 OUTLAB
(html,CSS,javascript,inkscape)



GROUP MEMBERS:
(Naveen Kumar,140050013)
(Yathansh Kathuria,140050021)
(Rajat Chaturvedi,140050027)


CONTRIBUTION BY EACH MEMBER:

Naveen Kumar (140050013) : 100% 
Yathansh Kathuria (140050021) : 100% 
Rajat Chaturvedi (140050027) : 100%


Instructions for our wewbpage:
1)To run the webpages successfully all the html files, .css files, .js files and the images should be in the same folder.

2)On the page Contact ME, howering on any of the links on the right will open some of my contact information. 

3)In the INKSCAPE page, howering on any room will show its name on the top, and if 3D image is available for the same, it will bw shown on the right.


HONOUR CODES:


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any other previous task.

														-Naveen Kumar(140050013)


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

													-Yathansh Kathuria(140050021)


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

													-Rajat Chaturvedi(140050027)





CITATIONS

1. www.w3schools.com
2. www.inkscape.com
3. help.ubuntu.com
4. www.stackoverflow.com
5. piazza.com
6. www.html5canvastutorials.com
7. www.tinypng.com
8. www.compressor.io
9. www.sitepoint.com
10. www.facebook.com
11. libregraphicsworld.org
12. www.penguintutorials.com
13. www.youtube.com
14. www.schillmania.com
15. www.ecoeco.com
16. www.picatutorial.com

Also thanks to the Instructor and classmates on Piazza for alll the help and guidance.






	

