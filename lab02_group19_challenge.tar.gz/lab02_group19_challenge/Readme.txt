CS 251
LAB O2 Challange Question 
Group 19
INFICODERS
Group Members:
(Naveen Kumar, 140050013)
(Yathansh Kathuria,140050021)
(Rajat Chaturvedi, 140050027)

Contribution by each memner:
1)Naveen Kumar,140050013: 90%
2)Yathansh Kathuria,140050021: 100%
3)Rajat Chaturvedi,140050027: 100%


Instructions:
1)fill in all the blocks in the sudoku and click on check button to check your solution

2)click on the reset button anytime to reset the values.

HONOUR CODES:

I pledge on my honour that I have not received or given any unauthorized help on this or any other previous assignment.
						-Naveen Kumar

I pledge on my honour that I have not received or given any unauthorized help on this or any other previous assignment.
						-Yathansh Kathuria

I pledge on my honour that I have not received or given any unauthorized help on this or any other previous assignment.
						-Rajat Chaturvedi

Citations:

1)websudoku.com
2)onlinekillersudoku.com
3)w3schools.com
4)stackoverflow.com
5)wikipedia.com
6)discussion forum on piazza

