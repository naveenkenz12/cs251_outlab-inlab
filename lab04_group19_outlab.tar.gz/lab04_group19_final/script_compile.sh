#!/bin/bash
touch good.txt
touch bad.txt
>good.txt
>bad.txt
ls -a | grep *.c | while read LINE; do
	if gcc -c -Werror $LINE  >/dev/null 2>&1; then
		echo $LINE >> good.txt
	else 
		echo $LINE >> bad.txt
	fi
done
