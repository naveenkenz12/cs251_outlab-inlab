#!/bin/bash
a1='<'			
b1='>'
a2='"'
if [ -z "$1" ]; then
 echo no file to check...
fi
while read LINE  
do 
	if [[ $LINE != //* ]] ; then
		if   [[ $LINE == '#'*include*'<'*'>'* ]]  ; then
			ini=${LINE:0:1}
			LINE=${LINE##$ini*$a1}
			fin=${LINE: -1}
			LINE=${LINE%%$b1*$fin}
			echo $LINE | tr -d '<' | tr - '>'
		elif [[ $LINE == '#'*include*'"'*'"'* ]]; then
			ini=${LINE:0:1}
			LINE=${LINE#$ini*$a2} 
			fin=${LINE: -1}
			LINE=${LINE%$a2*$fin}
			echo $LINE | tr -d '"'
		fi
	fi

done <$1  
