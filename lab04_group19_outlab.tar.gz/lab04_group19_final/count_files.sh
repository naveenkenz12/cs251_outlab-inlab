#!/bin/bash

ls -a | wc -l | while read LINE; do
	a=$LINE
    ls -d */ | wc -l | while read LINE; do
    	b=$LINE
    	ls -d .*/ | wc -l | while read LINE; do
    		c=$LINE
    		echo $[$a-$b-$c]
    		echo $[$b+$c]
    		done
    done
done 

