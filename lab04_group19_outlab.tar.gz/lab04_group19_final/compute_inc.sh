#!/bin/bash
#h
input_file=population.csv
touch population\_inc.csv
output_file=population\_inc.csv
>$output_file
IFS=,
i=0;
read year_prev pop_prev < $input_file 
while read year_nex pop_nex || [[ -n "$pop_nex" ]]
do
	i=$[i+1]
	year_out=$year_nex
	pop_out=$[$pop_nex - $pop_prev]
	if [ $i != 1 ]
	then
		echo "$year_out, $pop_out" >> $output_file
	fi
	year_prev=$year_nex
	pop_prev=$pop_nex	
done < $input_file
