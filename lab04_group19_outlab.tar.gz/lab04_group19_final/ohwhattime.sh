#!/bin/bash
file_name=$1
if [ ! -e $file_name ]
then	
	exit 1
fi
date -r $file_name +%m >> temp.txt
date -r $file_name +%d >> temp.txt
date -r $file_name +%H >> temp.txt
date -r $file_name +%M >> temp.txt
input=temp.txt
i="0"
while read num;do 
i=$[i+1]
if [ $i == 4 ]; then
	str+=":$num"
else
	str+="_$num"
fi
done < $input
cp $file_name "$file_name$str"

rm temp.txt
