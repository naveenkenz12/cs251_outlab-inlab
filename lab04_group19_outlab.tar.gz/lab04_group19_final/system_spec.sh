#!/bin/bash
cat /proc/cpuinfo | grep -i mhz | while read LINE; do
	a=${LINE:0:1}
	b=':'
	LINE=${LINE#$a*$b}
	echo $LINE MHz
	break
done
cat /proc/cpuinfo | grep 'address size'| while read LINE; do
	a=${LINE:0:1}
	b=':'
	LINE=${LINE#$a*$b}
	LINE1=${LINE%'physical'*'virtual'}
	c=${LINE:0:1}
	LINE2=${LINE#$c*','}
	LINE2=${LINE2%' '*'virtual'}
	echo $LINE1 
	echo $LINE2 
	break
done