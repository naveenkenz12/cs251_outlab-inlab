Cs 251
Group19
LAB 07 INLAB

group members :
1) Naveen Kumar (140050013) : 100%
2) Yathansh Kathuria (140050021) : 100%
3) Rajat Chaturvedi (140050027) : 100%

Observations:
Q1)
In the first patch, a total of 4 changes were made. Lines 64, 65 were added, 73 was deleted, and 75, 80-84 were changed.
In the second patch, a total of 2 changes were made. Lines 23-26 were deleted, and 50,51 were changed.

Instructions:
Q2)
To run the program, change into the directory of the file, and enter command as "python3 comment_finder.py [filename]"
Note : The file should be located in the same directory as the python file.


Honour Code:
I pledge on my honour that I have not recieved or given any unauthorised assistance in this or any other previous task.
			- Naveen Kumar

I pledge on my honour that I have not recieved or given any unauthorised assistance in this or any other previous task.
			-yathansh kathuria

I pledge on my honour that I have not recieved or given any unauthorised assistance in this or any other previous task.
			- Rajat Chaturvedi


Citations:
1)atlassian.com
2)tutorialspoint.com
3)stackoverflow.com
4)pythonforbeginners.com
5)git-scm.com
6)pymbook.readthedocs.org
