import sys
fh=open(sys.argv[1],'r')
fout=open("text_code_out.txt",'w')
check=False
for line in fh:
	n=len(line)
	if check==True:
		str="*/"
		k=line.find(str)
		if k==-1:
			fout.write(line)
		else:
			for j in range(0,k+2):
				fout.write(line[j])
			fout.write('\n')   
	for i in range (0,n-1):
		if line[i]=='/' and line[i+1]=='*':
			check=True
			for j in range (i,n):
				fout.write(line[j])
		if line[i]=='*' and line[i+1]=='/':
			check=False
		elif line[i]=='/' and line[i+1]=='/':
			for j in range (i,n):
				fout.write(line[j])

fh.close()
fout.close()

