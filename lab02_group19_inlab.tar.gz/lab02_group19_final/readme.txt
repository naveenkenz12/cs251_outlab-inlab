CS251
LAB02 INLAb
groupm 19
group members:
(naveen Kumar,140050013)
(yathansh kathuria,14005021)
(rajat chaturvedi,14005027)

contributions:
Naveen Kumar : 100%
Yathansh Kathuria : 100%
Rajat Chaturvedi : 100%

Honour Code:
I pledge on my honour that I have not recieved or given any unauthorised assistance in this or any other previous task.
			- Naveen Kumar

I pledge on my honour that I have not recieved or given any unauthorised assistance in this or any other previous task.
			-yathansh kathuria

I pledge on my honour that I have not recieved or given any unauthorised assistance in this or any other previous task.
			- Rajat Chaturvedi

Citations :
1	w3schools.com/html
2	piazza.com
3	help.ubuntu.com/community/mencoder
4	inkspace.com
5	wikipedia.org
6	Help and guidance from TAs and Instructor
