import java.math.*;
import java.io.*;
class Reader extends Thread implements Runnable
{
   private int id;
   private int val;
   private Thread t;
   private String threadName;
   private Book book;

   public Reader(int id,Book book)
   {
      this.id = id;
      this.threadName="reader"+id;
      this.book = book;
   }
   
   public synchronized void run()
   {  
      try
      {
        book.inNum();
      int n=(int) (Math.random()*3000);
      System.out.println("Reader "+id+" is Entering, Number of Readers: "+book.numReader);
      System.out.println("Reader "+id+" is Reading Book version: "+book.version);
      Thread.sleep(n);
      book.read();
      Thread.sleep(5000);
      book.deNum();
      System.out.println("Reader "+id+" is Leaving, Number of Readers: "+book.numReader);  
      
      }
   catch (InterruptedException e) {}
    }

    public void start ()
  {
    if (t == null)
    {
      t = new Thread (this, threadName);
      t.start ();
    }
  }
}
