import java.io.*;
import java.util.*;
public class BankApplication{
    public static Bank bank = new Bank();

    public static void main(String[] args)
    {
       
           
                AddAccountThread t1 = new AddAccountThread();
                DepositThread t3 = new DepositThread(1,100);
                DepositThread t4 = new DepositThread(1,100);
                WithdrawalThread t6 = new WithdrawalThread(1,500);
                DepositThread t5 = new DepositThread(2,100);
                AddAccountThread t2 = new AddAccountThread();
                t1.start();
                t3.start();
                t5.start();
                t2.start();
                t4.start();
                t6.start();
    }
}

