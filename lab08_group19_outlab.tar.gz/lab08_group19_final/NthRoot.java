import java.math.*;
import java.io.*;
import java.util.*;


public class NthRoot
{
	public static void main(String[] args)
	{
		int n;
		BigInteger big,big2;
		
		Scanner in = new Scanner(System.in);
 
     	System.out.println("Enter the Biginteger to find the nth root");
      	big = in.nextBigInteger();
      	
      	System.out.println("Enter the value of n to find the nth root");
      	n = in.nextInt();

      	BigDecimal bbb = NthRoot(big,n);
      	//bbb.setScale(6);
	
      	//System.out.println(bbb);
	bbb=bbb.divide(BigDecimal.ONE,6,RoundingMode.HALF_EVEN);
	System.out.println(bbb);
	
	}

	 public static BigDecimal NthRoot(BigInteger big,int n) 
	{
	    //BigDecimal result = new BigDecimal("30000000000.0");
	    BigDecimal result = new BigDecimal( Math.pow(big.doubleValue(),1.0/n) ) ;
	    //System.out.println(result);
	    BigDecimal b = new BigDecimal(big);
	    BigDecimal d = new BigDecimal(n);
	    BigDecimal bb=new BigDecimal("0.0000001");
	    
	    while((((result.add(bb)).pow(n)).compareTo(b)==-1&&(result.pow(n)).compareTo(b)==-1)||(((result.add(bb)).pow(n)).compareTo(b)==1&&(result.pow(n)).compareTo(b)==1))
	    {
	    	result = (result.add((result.divide(d,10,0)).negate())).add(b.divide(d.multiply(result.pow(n-1)),10,1));
	    	//System.out.println(result);

	    }
	    
	    //BigDecimal a = new BigDecimal("9.0");
	    //result = b.divide(a,10,1);
	    //result = result.setScale(6);
	    //System.out.println(result);
	    return result;
	}

	

}
