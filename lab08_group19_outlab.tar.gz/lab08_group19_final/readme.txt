CS 251
SOFTWARE SYSTEMS LAB
GROUP 19
inficoders
LAB 08 OUTLAB
(Java)

GROUP MEMBERS:

1. Naveen Kumar (140050013)
2. Yathansh Kathuria (140050021)
3. Rajat Chaturvedi (140050027)


CONTRIBUTION BY EACH MEMBER:

Naveen Kumar (140050013) : 100% 
Yathansh Kathuria (140050021) : 100% 
Rajat Chaturvedi (140050027) : 100%



HONOUR CODES:


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any other previous assignments.

														-Naveen Kumar(140050013)


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

													-Yathansh Kathuria(140050021)


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

													-Rajat Chaturvedi(140050027)


CITATIONS

1. javatpoint.com
2. tutorialspoint.com
3. docs.oracle.org
4. piazza.com
5. stackoverflow.com
6. herongyan.com
7. vogella.com
8. java-samples.com
9. informit.com

special thanks to the Instructorr and TAs for their guidance







	
