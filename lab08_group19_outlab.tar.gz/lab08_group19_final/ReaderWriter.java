import java.io.*;
import java.lang.*;



public class ReaderWriter extends Thread
{
   public static void main(String args[]) 
   {
      boolean a[] = new boolean[26];
      boolean c[] = new boolean[26];
      int av[] =new int[26];
      //int cv[] =new int[26];
      boolean b;
      for(int xx=0;xx<=25;xx++)
      {a[xx]=false;
      c[xx]=false;}
      b=false;
      Book book = new Book();
      
      int n,m;
      int i=1,k=1,j=0;
      Writer W1 = new Writer( book );
      W1.start();
      while(i<=40 || k<=4)
      {
        n=(int)(Math.random() * 25 + 1);
        if( k<=4  && n>=10 && book.numReader==0)
        {
          
            if(W1.isAlive()==false)
            {
              W1.start();
              k++;
            }
            //System.out.print(k);
        }
        else if(a[n]==false && i<=40 && n<=20 && book.mode==0)
          {
            try
            {
              Reader R1 = new Reader( n,book );
              R1.start();
              av[n]=book.version;
              R1.sleep((int)(Math.random()*6000));
              a[n]=true;
              i++;
            }
            catch (InterruptedException e){}
          }
          
        else if(a[n]==true && c[n]==false && i<=40 && n<=20 && book.mode==0 && av[n]!=book.version)
        {
        	try
            {
              Reader R1 = new Reader( n,book );
              R1.start();
              R1.sleep((int)(Math.random()*6000));
              c[n]=true;
              i++;
            }
            catch (InterruptedException e){}
        }
        
          
      }

   }   
}