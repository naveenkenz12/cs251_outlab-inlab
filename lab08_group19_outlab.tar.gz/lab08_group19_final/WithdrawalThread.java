import java.io.*;
import java.util.*;
class WithdrawalThread extends Thread
{
	private Thread thread;
	private Bank mybank;
	private int acctno;
	private int amount;
	public WithdrawalThread(int actno, int am)
	{
		mybank=BankApplication.bank;
		acctno=actno;
		amount=am;
	}
	public void start()
	{
		if(thread==null)
		{
			thread= new Thread(this);
			thread.start();
		}
	}
	public void run()
	{
		synchronized (BankApplication.bank)
		{
		try {
         Thread.sleep(5*1000); // working period
      	} catch (InterruptedException e){}
		if(acctno<=0||acctno>mybank.count)
		{
			System.out.println("Wrong Account Number \n");
			return;
		}
		else if(amount>mybank.Accounts.get(acctno-1).Balance)
		{
			System.out.println("Not enough Balance \n");
			return;
		}
		mybank.Accounts.get(acctno-1).Balance-=amount;
		System.out.println(amount+" Amount has been added in Account: "+acctno+", New balance: "+mybank.Accounts.get(acctno-1).Balance+"\n");
		}
	}
}

