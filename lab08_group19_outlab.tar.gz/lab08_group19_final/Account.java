import java.io.*;
import java.util.*;
class Account
{
	public int AccountNumber;
	public int Balance;
	public Account(int actno)
	{
		AccountNumber=actno;
		Balance=0;
	}
	
}

