import java.math.*;
import java.io.*;

class Writer extends Thread implements Runnable
{
   private String message1;
   private String message2;
   private Thread t;
   private String threadName;
   private Book book;
   public boolean b;
   public Writer(Book book)
   {
      this.message1 = "Writer is Entering";
      this.message2 = "Writer is Leaving";
      this.threadName = "writer";
      this.book = book;
   }
   
   public synchronized  void run() 
   {
    try
    {
      book.mode=1;
      System.out.println(message1);
      this.b=true;
      Thread.sleep(10000);
      book.write();
      book.changeVersion();
      Thread.sleep(2000);
      //wait();
      this.b=false;
      System.out.println(message2);
      book.mode=0;
    }
    catch (InterruptedException e) {}
   }
   public void start () 
  {
    run();
  }

}
