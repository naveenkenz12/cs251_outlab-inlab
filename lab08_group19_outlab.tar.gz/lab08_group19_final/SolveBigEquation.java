import java.math.*;
import java.io.*;
import java.util.*;

public class SolveBigEquation
{
	public static void main(String[] args)
	{
		BigInteger big50 = BigInteger.ONE;

		BigInteger four = new BigInteger("4");
		BigDecimal b = new BigDecimal("2.0");
		for (int i=1; i<=50; i++) 
		{
	        big50 = big50.multiply(BigInteger.valueOf(i));
	    }
	   	//System.out.println(big50);
	    BigInteger big100 = big50;
	    for(int j=51;j<=100;j++)
	    {
	    	big100 = big100.multiply(BigInteger.valueOf(j));
	    }
	    //System.out.println(big100);
	    BigInteger bigsq50 = big50.multiply(big50);
	    BigInteger b22=bigsq50.add(big100.multiply(four));
	    BigDecimal bin=NthRoot(b22,2);
	    BigDecimal binn=bin.negate();
	    //System.out.println(b22);
	    //System.out.println(bin.pow(2));
	    BigDecimal b50=new BigDecimal(big50);
	    BigDecimal b100=new BigDecimal(big100);

	    BigDecimal a1=(b50.add(bin)).divide(b);
	    BigDecimal a2=(b50.add(binn)).divide(b);
	    BigDecimal b1=b100.divide(a1,3,0);
	    BigDecimal b2=b100.divide(a2,3,0);
	    a1 = a1.divide(BigDecimal.ONE,3,0);
	    a2 = a2.divide(BigDecimal.ONE,3,0);
	    
	    System.out.println(b2+","+a2);
	    System.out.println(a2+","+b2);
	    System.out.println(b1+","+a1);
	    System.out.println(a1+","+b1);
	}

	 public static BigDecimal NthRoot(BigInteger big,int n) 
	{
	    //BigDecimal result = new BigDecimal("30000000000.0");
	    BigDecimal result = new BigDecimal( Math.pow(big.doubleValue(),1.0/n) ) ;
	    //System.out.println(result);
	    BigDecimal b = new BigDecimal(big);
	    BigDecimal d = new BigDecimal(n);
	    BigDecimal bb=new BigDecimal("0.0000001");
	    
	    while((((result.add(bb)).pow(n)).compareTo(b)==-1&&(result.pow(n)).compareTo(b)==-1)||(((result.add(bb)).pow(n)).compareTo(b)==1&&(result.pow(n)).compareTo(b)==1))
	    {
	    	result = (result.add((result.divide(d,100,0)).negate())).add(b.divide(d.multiply(result.pow(n-1)),100,1));
	    	//System.out.println(result);
	    }
	    
	    //BigDecimal a = new BigDecimal("9.0");
	    //result = b.divide(a,10,1);
	    //result = result.setScale(6);
	    //System.out.println(result);
	    return result;
	    
	}
}
