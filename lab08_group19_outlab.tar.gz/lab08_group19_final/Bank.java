import java.io.*;
import java.util.*;
class Bank 
{
	public Vector<Account> Accounts;
	public int count;
	public Bank()
	{
		count=0;
		Accounts= new Vector<Account> ();
	}
}

