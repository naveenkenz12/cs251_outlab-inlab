class Book extends Thread
{
   private static int content;
   public int numReader=0;
   public int version =0;
   public int mode = 0;

   public void changeVersion()
   {
      this.version = this.version+1;
   }
   public Book()
   {
      this.content = 0;
   }
   public void inNum()
   {
    this.numReader=this.numReader+1;
   }
   public void deNum()
   {
    this.numReader=this.numReader-1;
   }
   public void write()
   {
      this.content = this.content+1 ;
   }
   public int read()
   {
      return this.content;
   }
   
}