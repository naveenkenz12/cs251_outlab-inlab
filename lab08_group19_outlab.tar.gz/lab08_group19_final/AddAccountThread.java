import java.io.*;
import java.util.*;
class AddAccountThread extends Thread
{
	private Thread thread;
	private Bank mybank;
	public AddAccountThread()
	{
		mybank=BankApplication.bank;
		thread=null;
	}
	
	public void run()
	{
		synchronized (BankApplication.bank)
		{
		Account acc=new Account(++mybank.count);
		mybank.Accounts.add(acc);//System.out.println("Hello");
		System.out.println("Account with Account Number "+mybank.count+" has been created \n");
		}
	}
	public void start()
	{
		if(thread==null)
		{
			thread= new Thread(this);
			thread.start();
		}
//run();
	}
}

