CS 251
LAB 06 OUTLAB
GROUP 19
INFICODERS

Group Members:
1) Naveen Kumar,140050013
2) Yathansh Kathuria, 140050021
3) Rajat Chaturvedi, 140050027

Individual Contributions:
1) Naveen Kumar : 100%
2) Yathansh Kathuria : 100%
3) Rajat Chaturvedi : 100%

Instructions:

Question 1

1. Using the cd command, open the directory in which the files are stored, i.e., cd [Path to directory]

2. Now run make plot, and follow the on-screen instructions.

3. The required .png file will be generated, showing the plot of the curve along with the path showing the working of gradient_descent.

Question 2 and Question 3
1. Using the cd command, open the directory in which the files are stored, i.e., cd [Path to directory]

2. Now run make GayatriMantra, for GayatriMantra.pdf

3. run make ProjectProposal, for ProjectProposal.pdf

4. run make clean, for cleaning all generated pdf files and others from the make command.

Honor Code:

I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Naveen Kumar


I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Yathansh Kathuria


I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Rajat Chaturvedi


Citations:

1) stackoverflow.com
2) gnuplot.org
3) gnuplotting.org
4) gnuplot.sourceforge.net
5) physics.ohio-state.edu
6) www.chemie.fu-berlin.de
7) http://gnuplot-tricks.blogspot.in/
8) mathworks.com
9) piazza.com
10) bibtex.org
11) https://www.engineersedge.com/engine_formula_automotive.htm
12) https://www.sharelatex.com/learn/Line_breaks_and_blank_spaces#Line_breaks
13) sharelatex.com
14) tex.stackexchange.com
15) pravin.paratey.com/files/devanagari.pdf

Also thanks to all the TAs and the instructor for their help and guidance.
