#//func=input()
#//dx=gradient(func)
#//subplot(func)
#//hold
#//subplot(dx)
k=input("Enter a function \n","s");
file=fopen("output.dat","w");
function z=f(k,x,y)
z=eval(k);
endfunction
x1(1)=-100;
y1(1)=100;
z1(1)=f(k,x1(1),y1(1));
fprintf(file,"%g %g %g",x1(1),y1(1),z1(1));
for i=2:1000000
dx=(f(k,x1(i-1)+0.00000001,y1(i-1))-f(k,x1(i-1),y1(i-1)))/0.00000001;
dy=(f(k,x1(i-1),y1(i-1)+0.00000001)-f(k,x1(i-1),y1(i-1)))/0.00000001;
x1(i)=x1(i-1) - 0.1*dx;
y1(i)=y1(i-1) - 0.1*dy;
if (abs(dx)<0.001 || abs(dy)<0.001 )
	break;
endif
 
z1(i)=f(k,x1(i),y1(i));
fprintf(file,"%g %g %g \n",x1(i),y1(i),z1(i));
endfor
fclose(file);

filename = "plot.gnu";
fid = fopen (filename, "w");
fprintf(fid,"set xrange[-100:100] \n");
fprintf(fid,"set yrange[-100:100] \n");
fprintf(fid,"set term png \n");
fprintf(fid,"set output 'plot.png' \n");
fprintf(fid, "splot %s, 'output.dat' with linespoint",k);
fclose (fid);
