import csv
import re
fobj = open("tenth.txt", "r")
fh = open("cbseProcessed.csv", "w")
fcsv=csv.writer(fh, delimiter=',')
line2=' '
line1=' '
for line in fobj:
	if line[0]=='R':
		line1=line
		line1=line1+' '
	elif line1[0]=='R':
		line2=line1+line
		line2=re.sub('\.+', ' ', line2)
		line2=line2.split()
		line1=' '
		line2[0]=line2[0]+'_'+line2[1]
		del line2[1]
		line2[1]=line2[1]+'_'+line2[2]
		del line2[2]
		line2[19]=line2[19]+'_'+line2[20]
		del line2[20]
		line2[20]=line2[20]+'_'+line2[21]
		del line2[21]
		line2[21]='PART_'+line2[21]
		line2[22]=line2[22]+'_'+line2[23]
		del line2[23]
		line2[23]=line2[23]+'_'+line2[24]
		del line2[24]
		line2[24]=line2[24]+'_'+line2[25]
		del line2[25]
		line2[25]=line2[25]+'_'+line2[26]
		del line2[26]
		for i in range (0,5):
			line2.insert(20,' ')
		line2.insert(26,' ')
		line2.insert(28,' ')
		for i in range (0,7):
			line2.insert(30,' ')
		for i in range (0,3):
			line2.insert(38,' ')
		for i in range (0,3):
			line2.insert(42,' ')
		fcsv.writerow(line2)
		break
for line in fobj:
    if line[0]=='4':
    	line1=line.strip()
    	if line1[-1]=='P':
    		line1=line1+' NA '
    	else:
    		line1=line1+' '
    elif line1[0]=='4':
    	line2=line1+line.strip()+' '
    	line1=' '
    	line2=line2.split()
    	i=2
    	check=True
    	while check==True:
    		if i>=6 or line2[i][0]=='1' or line2[i][0]=='2' or line2[i][0]=='0':
    			check=False
    			break
    		else:
    			line2[1]=line2[1]+'_'+line2[i]
    			del line2[i]
    	fcsv.writerow(line2)
fh.close()
fobj.close()

