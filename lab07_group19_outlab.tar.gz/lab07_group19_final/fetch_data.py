#!/usr/bin/env python3
import csv
import sys
if len(sys.argv) != 2:
	print("Input should be : ./fetch_data.py [csvfile_name]")
	sys.exit(1) 
j=-1
file1=open(sys.argv[1])
count=0
myfile = []
selfile = []
dicti = {}
sum1=0
reader1=csv.reader(file1, delimiter=',')
for row in reader1:
	if row[0]=='Sno':
		for i in range(0,6):
			dicti[row[i]] = i
		continue
	try:
		int(row[0])
		myfile.append(row)
		count+=1
	except ValueError:
		continue
for i in range(0,len(myfile)):
	sum1=0
	for j in range(1,6):
		if myfile[i][j]=="NA":
			myfile[i][j]=0
		myfile[i][j]=float(myfile[i][j])
		sum1+=myfile[i][j]
	myfile[i].append(sum1)
selfile=list( filter((lambda x: int(x[6])==1), myfile))
myfile.sort(key = lambda x: x[7])
file1.close()
file1 = open("marks_sorted.csv",'w')
writer1 = csv.writer(file1,  delimiter = ',')
for i in range(0,len(myfile)):
	writer1.writerow(myfile[i])
print("Part (a) : %d" % count)
print("Part (b) : %d" % len(myfile))
print("Part (c) : %d" % len(selfile))
print("Part (d) :")
for x,y in dicti.items():
	print("\t",x,"\t", y) 
