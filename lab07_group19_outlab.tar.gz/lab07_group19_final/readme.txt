CS 251
LAB 07 OUTLAB
GROUP 19
INFICODERS

Group Members:
1) Naveen Kumar,140050013
2) Yathansh Kathuria, 140050021
3) Rajat Chaturvedi, 140050027

Individual Contributions:
1) Naveen Kumar : 100%
2) Yathansh Kathuria : 100%
3) Rajat Chaturvedi : 100%

Instructions:
Q1)
After pushing changes from "second" to "remorerepo", I tried to make some changes to "observeConflict.txt" in "first" and push it.
This resulted in a "conflict error", showing AUTO-merge failed.
Now when I tried to pull "remoterepo" into "first", again it showed "conflict" error saying your branch is not updated.
Now when i opened the file "obserceConflict.txt" in "first", it showed me contents of both the files that were conflicted.
I manually deleted the content that I did not require, and committed "first" again, and pushed it.
This resulted in a successful push, and now "first" and "remoterepo" are in sync.

Q2)
to run the program, change to the directory containing it and type:
	python3 fetch_data.py [filename]
NOTE: both the files should be in the same directory


Q3)
to run the program, change to the directory containing it and type:
	python3 text_to_csv.py
 

Honor Code:

I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Naveen Kumar


I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Yathansh Kathuria


I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Rajat Chaturvedi


Citations:

1) tutorialspoint.com
2) pymotw.com
3) docs.python.org
4) stackoverflow.com
5) learnpythonthehardway.org
6) python-course.eu
7) pythonforbeginners.com
8) wiki.python.org
9) pymbook.readthedocs.org
10)bogotobog.com
11)mail.python.org
12)newcircle.com
13)githowto.com
14)help.github.com
15)atlassian.com
16)rogerdudler.github.io
17)digitalocean.com
 
