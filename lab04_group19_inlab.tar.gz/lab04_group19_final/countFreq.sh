#!/bin/bash
read str
(tr ' ' '\n' | uniq -c | awk '{print "frequency of " $2 " is " $1}' ) <<EOF
$str
EOF