#!/bin/bash
user=$1
host=$2
if [ -z "$user" -o -z "$host" ]
	then
		echo "invalid input : parameter missing"
fi
if [ $1@$2 ]; then
	exit 0
fi
ssh-add ~/.ssh/id_rsa
ssh-keygen
scp ~/.ssh/id_rsa.pub $1@$2:pubkey
ssh $user@$host "cat pubkey > ~/.ssh/authorized_keys"
