CS 251
SOFTWARE SYSTEMS LAB

GROUP 19
inficoders
LAB 04 INLAB
(bash)

GROUP MEMBERS:

1. Naveen Kumar (140050013)
2. Yathansh Kathuria (140050021)
3. Rajat Chaturvedi (140050027)



CONTRIBUTION BY EACH MEMBER:

Naveen Kumar (140050013) : 100% 
Yathansh Kathuria (140050021) : 100% 
Rajat Chaturvedi (140050027) : 100%






Instructions:
Q1 a) To run this script, first change its permissions to 755 or 700. Now run the command ./makePasswordless.sh [username] [hostname]
   b) Run this script to change your nick to "mymars", for easy login to your account.
   c) Use the command ./syncToMars.sh [folder] [usernick] to copy the folder into a remote host.
Q2 Run this script and enter a sequence of words with or without repitition separated by blank spaces and press Enter.
	The script complexity is O(n log n).

HONOUR CODES:


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any other previous task.

														-Naveen Kumar(140050013)


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

													-Yathansh Kathuria(140050021)


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

													-Rajat Chaturvedi(140050027)


CITATIONS

1.stackoverflow.com
2.http://programmers.stackexchange.com/questions/241052/time-complexity-implications-when-designing-shell-scripts-for-large-data-high-nu
3.tdlp.org
4.askubuntu.com
5.cyberciti.biz
6.commandlinefu.org
7.http://www.thegeekstuff.com/2009/10/how-to-execute-ssh-and-scp-in-batch-mode-only-when-passwordless-login-is-enabled/
8.www.saltycrane.com
9.http://ryanstutorials.net/bash-scripting-tutorial/
10.https://d1b10bmlvqabco.cloudfront.net/attach/ic5kd9di29817i/hzd1ujgt255nd/idbzg0hzd3tx/absguide.pdf
11.http://www.delorie.com/gnu/docs/gawk/gawk_204.html
12.discussions on piazza

Special thanks to the Professor and TAs for their guidance






	
