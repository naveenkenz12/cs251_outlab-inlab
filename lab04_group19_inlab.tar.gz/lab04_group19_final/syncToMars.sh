#!/bin/bash
fol=$1
rh=$2
rsync -a ~/$fol/ $rh:$fol