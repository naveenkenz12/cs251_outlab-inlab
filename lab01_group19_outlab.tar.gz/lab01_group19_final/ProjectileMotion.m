printf("%s\n","Enter Initial Cordinates:");
global a1; 
global b1;
global a2;
global b2;
global u;
global a;
global b;

a1=input("x0 = ");
b1=input("y0 = ");
printf("%s\n","Enter Target Cordinates:");
a2=input("xf = ");
b2=input("yf = ");
printf("%s\n","Enter Initial Velocity:");
u=input("u = ");
g=9.8;
k=0.05;
a=a2-a1;
b=b2-b1;


if(a!=0)								%CASE I: done by using the quadratic formula when displacemet in x is 
	D1=a*a-2*(g*a*a/(u*u))*(b+0.03+g*a*a/(2*u*u));			% not 0 i.e. angle is not 90 degree.
	D2=a*a-2*(g*a*a/(u*u))*(b-0.03+g*a*a/(2*u*u));			%calculating discriminant for b+0.03 and b-0.03
	R1=(a-sqrt(D1))/(g*a*a/(u*u));
	R2=(a-sqrt(D2))/(g*a*a/(u*u));
	R3=(a+sqrt(D1))/(g*a*a/(u*u));
	R4=(a+sqrt(D2))/(g*a*a/(u*u));

	if(D1<0 && D2<0)						%checking number of possible ranges and printing them.
		printf("Case I : Not Possible for This Case.\n")
	elseif(D1>=0 && D2<0)
		printf("Case I : Only Possible Range of Angle in Degree is from: \n        %.2f to %.2f .\n",atan(R2)*180/pi,atan(R1)*180/pi)
	elseif(D2>=0 && D1<0)
		printf("Case I : Only Possible Range of Angle in Degree is from: \n        %.2f to %.2f .\n",atan(R3)*180/pi,atan(R4)*180/pi)
	elseif(D1>=0 && D2>=0)
		printf("Case I : Possible Ranges of Angle in Degree is from: \n         %.2f to %.2f and from %.2f to %.2f .\n",atan(R2)*180/pi,atan(R1)*180/pi,atan(R3)*180/pi,atan(R4)*180/pi)
	endif
	elseif(a==0)							%when angle is 90 degree 
	if(b<=(u*u/(2*g)))
		printf("Case I : Only Possible Angle in degree is 90.\n");
	else
	printf("Case I : Not Possibvle for this Case.\n");
	endif
endif

									%CASE II (done by Newton raphson method)
if(a!=0)									
	function f2=func1(x)
		global a;
		global b;
		global u;
		k=0.05;
		g=9.8;
		f2=a*x+g*a*sqrt(1+x*x)/(k*u)+(g/(k*k))*log(1-a*k*sqrt(1+x*x)/u)-(b+0.03);	%f(x) for newton raphson method for b+0.03
	endfunction

	function f21=func2(x)
		global a;
		global b;
		global u;
		k=0.05;
		g=9.8;
		f21=a*x+g*a*sqrt(1+x*x)/(k*u)+(g/(k*k))*log(1-a*k*sqrt(1+x*x)/u)-(b-0.03);	%f(x) for newton raphson method for b-0.03
	endfunction

	function eq=eqw(x)
		global a;
		global b;
		global u;
		g=9.8;
		k=0.05;
		eq=a+g*a*x/(u*k*sqrt(1+x*x))-g*a*x/(k*sqrt(1+x*x)*(u-a*k*sqrt(1+x*x)));		%diffrentiationf(x) for newton raphson method 
	endfunction;

	angg=1;
	while(abs(func1(angg))>=0.000001)						%basic recursion for NR Method
		angg=angg-func1(angg)/eqw(angg);
	endwhile
		c11=atan(angg)*180/pi;
	
	angg=1;										
	while(abs(func2(angg))>=0.000001)
		angg=angg-func2(angg)/eqw(angg);
	endwhile
			c12=atan(angg)*180/pi;
	
	angg=30;
	
	while(abs(func1(angg))>=0.000001)						%to get the second range
		angg=angg-func1(angg)/eqw(angg);
	endwhile
	c21=atan(angg)*180/pi;

	angg=30;
	while(abs(func2(angg))>=0.000001)
		angg=angg-func2(angg)/eqw(angg);
	endwhile
	c22=atan(angg)*180/pi;
	
	if((isreal(c11)==0||isreal(c12)==0)&&(isreal(c21)==0 || isreal(c22)==0))	%to check number of possible solutions and printing them
		printf("Case II : No Possible Angle for This Case.\n")
	elseif((isreal(c11)==1&&isreal(c12)==1)&&(isreal(c21)==0 || isreal(c22)==0))
		printf("Case II : Only Possible Range of angle in degree is from: \n             %.2f to %.2f .\n",min(c11,c12),max(c11,c12))
	elseif((isreal(c11)==0||isreal(c12)==0)&&(isreal(c21)==1 && isreal(c22)==1))
		printf("Case II : Only Possible Range of angle in degree is from: \n             %.2f to %.2f .\n",min(c21,c22),max(c21,c22))
	elseif((isreal(c11)==1&&isreal(c12)==1)&&(isreal(c21)==1 && isreal(c22)==1))
		printf("Case II : Possible Ranges of angle in degree is from: \n          %.2f to %.2f and from %.2f to %.2f .\n",min(c11,c12),max(c11,c12),min(c21,c22),max(c21,c22))
	endif

elseif(a==0)										%special case: when angle is 90 degree
	if(b<=(u/k)-(g/(k*k))*log(1+k*u/g))
		printf("Case II : Only Possible angle in degree is 90.\n")
	else
		printf("Case II : Not Possible for this value.\n")
	endif
endif

								%CASE III (done by Newton Raphson Method)
if(a!=0)	
	function fd3=funcd3(x)
	global a;
	global b;
	global u;
	g=9.8;
	k=0.05;
	fd3=(-1/k)*tan(sqrt(g*k*(1+x*x))*(exp(a*k)-1)/(k*u)-atan(sqrt(k/(g*(1+x*x)))*u*x))*(sqrt(g*k/(1+x*x))*(exp(a*k)-1)*x/(k*u)-sqrt(k/(g*(1+x*x)))*g*u/(k*u*u*x*x+g*(1+x*x)))-(1/k)*(x/(1+x*x)-(g*x+k*u*u*x)/(k*u*u*x*x+g*(1+x*x)));
endfunction							%derivative of f(x) for NR Method


	function cas3=case3(x)
		global a;
		global b;
		global u;
		g=9.8;
		k=0.05;
		cas3=(1/k)*log(cos(sqrt(g*k*(1+x*x))*(exp(a*k)-1)/(k*u)-atan(sqrt(k/(g*(1+x*x)))*u*x)))-(1/(2*k))*log(g*(1+x*x)/(g*(1+x*x)+k*u*u*x*x))-(b+0.03);
endfunction			%f(x) for NR method (for b+0.03)

	function cas3d=case3d(x)
		global a;
		global b;
		global u;
		g=9.8;
		k=0.05;
		cas3d=(1/k)*log(cos(sqrt(g*k*(1+x*x))*(exp(a*k)-1)/(k*u)-atan(sqrt(k/(g*(1+x*x)))*u*x)))-(1/(2*k))*log(g*(1+x*x)/(g*(1+x*x)+k*u*u*x*x))-(b-0.03);
endfunction			%f(x) for NR method (for b-0.03)

	angg3=0.0001;
	i=0;
	
	while(abs(case3(angg3))>=0.00001 && i<10000)		%basic recursion for NR Method
		angg3=angg3-case3(angg3)/funcd3(angg3);
		i=i+1;
	endwhile
	c31=atan(angg3)*180/pi;

	angg3=0.0001;
	i=0;
	while(abs(case3d(angg3))>=0.00001 && i<100000)
		angg3=angg3-case3d(angg3)/funcd3(angg3);
		i=i+1;
	endwhile
	c32=atan(angg3)*180/pi;

	angg3=30;						%to get the second range	
	i=0;
	while(abs(case3(angg3))>=0.00001 && i<100000)
		angg3=angg3-case3(angg3)/funcd3(angg3);
		i=i+1;
	endwhile
	c33=atan(angg3)*180/pi;
	
	angg3=30;
	i=0;
	while(abs(case3d(angg3))>=0.00001 && i<100000)
		angg3=angg3-case3d(angg3)/funcd3(angg3);
		i=i+1;
	endwhile
		c34=atan(angg3)*180/pi;


	if((isreal(c31)==0||isreal(c32)==0)&&(isreal(c33)==0 || isreal(c34)==0))	      %to check number of possible ranges and print them
		printf("Case III : No Possible Angle for This Case.\n")
	elseif((isreal(c31)==1&&isreal(c32)==1)&&(isreal(c33)==0 || isreal(c34)==0))
		printf("Case III : Only Possible Range of angle in degree is from: \n             %.2f to %.2f .\n",min(c31,c32),max(c31,c32))
	elseif((isreal(c31)==0||isreal(c32)==0)&&(isreal(c33)==1 && isreal(c34)==1))
		printf("Case III : Only Possible Range of angle in degree is from: \n             %.2f to %.2f .\n",min(c33,c34),max(c33,c34))
	elseif((isreal(c31)==1&&isreal(c32)==1)&&(isreal(c33)==1 && isreal(c34)==1))
		printf("Case III : Possible Ranges of angle in degree is from: \n          %.2f to %.2f and from %.2f to %.2f .\n",min(c31,c32),max(c31,c32),min(c33,c34),max(c33,c34))
	endif

elseif(a==0)								%special case: when a=0 i.e angle=90 degree i.e. no displacement in x.
	if(b<=(1/(2*k))*log(1+k*u*u/g))
		printf("Case III : Only Possible angle in degree is 90.\n");
	else
		printf("Case III : Not Possible for this Case.\n");
	endif
endif

