format rat				%to keep the values in rational form (as decimal notations can lead to precision loss) 
A=zeros(1000,1000);			%creates a zero matrix
fid=fopen("small.txt");			%opens the file from which data has to be read		
i=1;
while(i<=1000)
	str=fgetl(fid);			%fget reads one line of the file at a time	
	a=unique(strread(str));		%strread used to read one number at a time and unique used to SKIP REPEATED values (as multiple 	
	n=rows(a);			%links between two pages are to be neglected)
	j=1;
	while(j<=n)			%assigning values to the matrix
		A(a(j),i)=1/n;
		j=j+1;
	endwhile
	i=i+1;
endwhile
fclose("small.txt");
B=ones(1000,1000);			%creating a matrix all whose elements are 1
C=A+(3/(20*1000))*B;
[eignvector,eigenvalue]=eig(C);
lambda=diag(eigenvalue);
wantedRanks = eignvector(:,1);
z=1;
while(z<=1000)
	mat(z,1)=z;
	mat(z,2)=wantedRanks(z);
	z=z+1;
endwhile
mm=sort(wantedRanks,'descend');		%sorting the pages according to their ranks
format free;
s=1;
printf("%s","The Top 20 pages in decending order of their page rank are:\nPageID,PageRank\n")
while(s<=20)				%printing the top 20 pages
	[ix,iy]=find(mat==mm(s));
	printf("   %d,%f\n",ix,mm(s))
	s=s+1;
endwhile

