﻿CS 251
SOFTWARE SYSTEMS LAB

GROUP MEMBERS:

1. Naveen Kumar (140050013)
2. Yathansh Kathuria (140050021)
3. Rajat Chaturvedi (140050027)

GROUP 19
inficoders
LAB 01 OUTLAB
(Projectile Motion and Page Rank)

CONTRIBUTION BY EACH MEMBER:

Naveen Kumar (140050013) : 100% 
Yathansh Kathuria (140050021) : 100% 
Rajat Chaturvedi (140050027) : 100%


Instructions to Run ProjectileMotion.m:

1.To run the file through teminal directly, use the following commands:
             cd [folderdirectory]
	     octave ProjectileMotion.m

2.To run the file through Octave, use the following commands:
             cd [folderdirectory]
             ProjectileMotion

3.Once started you will have to give in the values of initial coordinates, the target coordinates and the throwing velocity

4.The program will return the possible range of angles for all the three cases (no air resistance, air resistance proportional to velocity and air resistance proportional to square of velocity)


Instructions to Run pagerank.m:

1.Keep small.txt and pagerank.m in same directory

2.To run the file through teminal directly, use the following commands:
             cd [folderdirectory]
	     octave pagerank.m

3.To run the file through Octave, use the following commands:
             cd [folderdirectory]
             pagerank

4. Once run this will automatically print the top 20 pages in descending order in the form of pageid,pagerank.



SPECIAL COMMENTS:
1. We tried many different methods to solve the equations (direct quadratic formula, Newton Raphson approach, fixed point iteration method, brute force method), this is quite visible from our code where we have used two different methods for the three cases:
	a) case 1 is done by direct quadratic formua
	b) case 2 and 3 are done by newton raphson method
	
2. We have looked for the cases where there are no possible solutions and are printing "no solutions for this case" for the same.

3. For most of the cases there would be 2 possible ranges of angles, and we are printing both of them. For some case where only 1 range exists, we print the same.

4. we have made a different case for the sitautions where change in x is 0 i.e. angle is 90 degrees because in those cases, tan of the angle will increase drastically (in our algorithms all operations are defined on tan(theta) as x and applied Newton Raphson Method in x).So,if change in x is 0,we can conclude that angle if possible will be 90 degree for all three cases. We calculated the maximum height in all the three cases, if the displacement in b is less than maximum height than the output will be "Not Possible For This Case".

4. In the second question for determinig pagerank, we observed that in the given datafile, there were instances where a single page was linked to another page more than once, we neglected such duplicacies by creating a function. We thought this was necessary as mentioned in the class  although even after ignoring the duplicacies the pagerank output was same.


HONOUR CODES:


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any other previous task.

														-Naveen Kumar(140050013)


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

													-Yathansh Kathuria(140050021)


I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

													-Rajat Chaturvedi(140050027)


CITATIONS

1.http://www.gnu.org/software/octave
2.octave.sourceforge.net
3.in.mathworks.com/help/matlab
4.farside.ph.utexas.edu/teaching/336k/Newtonhtml/node29.html
5.http://rhig.physics.wayne.edu/~pruneau/Courses/PHY5200/lectures/PHY5200-Chap2.pdf
6.stackoverflow.com
7.http://www.cs.princeton.edu/~chazelle/courses/BIB/pagerank.htm
8.http://pagerank.suchmaschinen-doktor.de/index/examples.html
9.code sample by the instructor on piazza
10.MA 106 lecture slides (for eigen value and eigen vector)
11.discussions on piazza

special thanks to the Professor and TAs for their guidance







	
