CS 251
LAB 09 OUTLAB
GROUP 19
INFICODERS

Group Members:
1) Naveen Kumar,140050013
2) Yathansh Kathuria, 140050021
3) Rajat Chaturvedi, 140050027

Individual Contributions:
1) Naveen Kumar : 100%
2) Yathansh Kathuria : 100%
3) Rajat Chaturvedi : 100%

Observations:
Q2)
Percentage time for each function:
1)main():100%
2)func1():called from main: 66.93%
3)new_func1():called from func1: 32.87%
4)func2():called from func2:32.97%

Honor Code:

I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Naveen Kumar


I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Yathansh Kathuria


I pledge on my honor that I have not given or received any unathorized help in this or any other previous task.
											- Rajat Chaturvedi


Citations:

1) te.stackexchange.com 
2) latex-project.org
3) net-iniformations.com
4) stackoverflow.org
5) stack.nl
5) piazza.com
6) thegeekstuff.com

