/*
 * Copyright (c) 2006-2009 Erin Catto http://www.box2d.org
 *
 * This software is provided 'as-is', without any express or implied
 * warranty.  In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 1. The origin of this software must not be misrepresented; you must not
 * claim that you wrote the original software. If you use this software
 * in a product, an acknowledgment in the product documentation would be
 * appreciated but is not required.
 * 2. Altered source versions must be plainly marked as such, and must not be
 * misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 */

/* 
 * Base code for CS 251 Software Systems Lab 
 * Department of Computer Science and Engineering, IIT Bombay
 * 
 */


#include "cs251_base.hpp"
#include "render.hpp"

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include "GL/freeglut.h"
#endif

#include <cstring>
using namespace std;

#include "dominos.hpp"


namespace cs251
{
    
  dominos_t::dominos_t()
  {
	//! **************************************************************************************************************************************\n
	//! desribing each element in the constructor\nn
    //! Bottom of the World ------------------------------------------------------------------------------------------------------------------\n
    
    //! This if the bottom line of the world as visible in the set up. \n
    //! All the objects are drawn above this line and all  \n
    //! activities takes place above that line in the world.\n
    b2Body* b1;  
    {
      
      b2EdgeShape shape; 
      shape.Set(b2Vec2(-90.0f, 0.0f), b2Vec2(90.0f, 0.0f));
      b2BodyDef bd; 
      b1 = m_world->CreateBody(&bd); 
      b1->CreateFixture(&shape, 0.0f);
    }
	//! **************************************************************************************************************************************\n
	//! Stand for the dominos ----------------------------------------------------------------------------------------------------------------\n
    //! This is rectangular plank on which the dominos rest. \n
    
    

    {
      b2PolygonShape shape;				/**< polygon shaped object */
      shape.SetAsBox(6.0f, 0.25f);		/**< rectangle shaped of size 6.0 * 0.25 */
	
      b2BodyDef bd;
      bd.position.Set(-31.0f, 30.0f);		/**< positioned at (-31.0,30.0) */
      b2Body* ground = m_world->CreateBody(&bd);
      ground->CreateFixture(&shape, 0.0f);
    }
	//! **************************************************************************************************************************************\n
	//! Dominos ------------------------------------------------------------------------------------------------------------------------------\n
    //! Dominos are the verticle box shaped structure that are hit by the pendulum. \n
    //! A toatal of ten dominos are there. \n
    
    {
      b2PolygonShape shape;			/**< polygon shaped dominos */
      shape.SetAsBox(0.1f, 1.0f);	/**< size of each dominos 0.1 * 0.1 */
	
      b2FixtureDef fd;				
      fd.shape = &shape;			
      fd.density = 20.0f;			/**< dominos density as 20 */
      fd.friction = 0.1f;		/**< friction as 0.1 */
		
      for (int i = 0; i < 10; ++i) 	/**< a total 10 dominos */
	{
	  b2BodyDef bd;
	  bd.type = b2_dynamicBody;		/**< all dominos as dynamicbody */
	  bd.position.Set(-35.5f + 1.0f * i, 31.25f); 
	  b2Body* body = m_world->CreateBody(&bd);
	  body->CreateFixture(&fd);
	}
    }
	
  	
    b2Body* b4;
    {
      b2PolygonShape shape;		
      shape.SetAsBox(0.25f, 0.25f);		
	  
      b2BodyDef bd;
      bd.type = b2_dynamicBody;
      bd.position.Set(-40.0f, 33.0f);
      b4 = m_world->CreateBody(&bd);
      b4->CreateFixture(&shape, 2.0f);
    }
	
      


    //The pendulum that knocks the dominos off
	//! **************************************************************************************************************************************\n
	//! The pendulum that knocks the dominos off ---------------------------------------------------------------------------------------------\n
    //! The pendulum knocks the first dominos which in turn pass the motion to next dominos. \n
    

    {
      b2Body* b2;
      {
	b2PolygonShape shape;		/**< polygon shaped pendulum */
	shape.SetAsBox(0.25f, 1.5f); 	/**< rectangle of size 0.25 * 1.5 */
	  	
	b2BodyDef bd;
	bd.position.Set(-36.5f, 28.0f);		/**< positioned at (-36.5 , 28.0) */
	b2 = m_world->CreateBody(&bd);
	b2->CreateFixture(&shape, 10.0f);
      }
	
      //Another horizontal shelf
	//! **************************************************************************************************************************************\n
	//! Another horizontal shelf where the dominos fall --------------------------------------------------------------------------------------\n
    //! After being knocked by the pendulum the dominos falls on thi shorizontal plank. \n
    //! This horizontal plank also contain a toatl of 10 tiny spheres.\n
    //! The dominos on falling to this horizontal plank pass on their motion to tiny spheres which later fall in the open box.\n

	
      {
	b2PolygonShape shape;		/**< polygon shaped shelf */
	shape.SetAsBox(7.0f, 0.25f, b2Vec2(-20.f,20.f), 0.0f);/**< size 7.0 * 0.25 , positioned at (-20.0,20.0) at an angle of 0 with horizontal*/
	
	b2BodyDef bd;
	bd.position.Set(1.0f, 6.0f);
	b2Body* ground = m_world->CreateBody(&bd);
	ground->CreateFixture(&shape, 0.0f);
      }

      b2RevoluteJointDef jd;
      b2Vec2 anchor;
      anchor.Set(-37.0f, 40.0f);
      jd.Initialize(b2, b4, anchor);
      m_world->CreateJoint(&jd);
    }
      
    //The train of small spheres
	//! **************************************************************************************************************************************\n
	//! The train of small spheres -----------------------------------------------------------------------------------------------------------\n
    //! There are a total of 10 tiny spheres which fall in the open box to provide motion to the pulley system. \n
   
    {
      b2Body* spherebody;
	
      b2CircleShape circle;		/**< sphere shaped */
      circle.m_radius = 0.5;		/**< ceach of readius 0.5 */
	
      b2FixtureDef ballfd;
      ballfd.shape = &circle;
      ballfd.density = 1.0f;		/**< density of sphere 1.0 */
      ballfd.friction = 0.0f;		/**< no friction between sphere and the horizontal surface */
      ballfd.restitution = 0.0f;	/**< coefficient of restitution is 0 */
	
      for (int i = 0; i < 10; ++i)
	{
	  b2BodyDef ballbd;
	  ballbd.type = b2_dynamicBody;		/**< all spheres are dynamic body */
	  ballbd.position.Set(-22.2f + i*1.0, 26.6f);
	  spherebody = m_world->CreateBody(&ballbd);
	  spherebody->CreateFixture(&ballfd);
	}
    }

    //The pulley system
	//! **************************************************************************************************************************************\n
	//! The pulley ---------------------------------------------------------------------------------------------------------------------------\n
    //! This uses the pulley joints. \n
    


    {
      b2BodyDef *bd = new b2BodyDef;
      bd->type = b2_dynamicBody;
      bd->position.Set(-10,15);
      bd->fixedRotation = true;
      
      //The open box

	//! The open box where the balls fall (a part of pulley system) --------------------------------------------------------------------------\n
    //! The open box forms the left side of the pulley system where the tiny spheres fall. \n
   //! The right side of pulley system consist of a horizontal bar to balance the weight of the left side. \n
	
	
	/**< open box made with three rectangles */
      b2FixtureDef *fd1 = new b2FixtureDef;
      fd1->density = 10.0;		/**< density of open box is 10.0 */
      fd1->friction = 0.5;		/**< friction of open box is 0.5 */
      fd1->restitution = 0.f;		/**< coefficient of restitution of open box is 0.0 */
      fd1->shape = new b2PolygonShape;
      b2PolygonShape bs1;
      bs1.SetAsBox(2,0.2, b2Vec2(0.f,-1.9f), 0);		/**< first rectangle placed at (0,-1.9) of size 2 * 0.2 */
      fd1->shape = &bs1;
      b2FixtureDef *fd2 = new b2FixtureDef;
      fd2->density = 10.0;
      fd2->friction = 0.5;
      fd2->restitution = 0.f;
      fd2->shape = new b2PolygonShape;
      b2PolygonShape bs2;
      bs2.SetAsBox(0.2,2, b2Vec2(2.0f,0.f), 0);		/**< second rectange placed at (2,0) of size 0.2 * 2 */
      fd2->shape = &bs2;
      b2FixtureDef *fd3 = new b2FixtureDef;
      fd3->density = 10.0;
      fd3->friction = 0.5;
      fd3->restitution = 0.f;
      fd3->shape = new b2PolygonShape;
      b2PolygonShape bs3;
      bs3.SetAsBox(0.2,2, b2Vec2(-2.0f,0.f), 0);	/**< third rectangle placed at (-2,0) of size 0.2 * 2 */
      fd3->shape = &bs3;
       
      b2Body* box1 = m_world->CreateBody(bd);
      box1->CreateFixture(fd1);
      box1->CreateFixture(fd2);
      box1->CreateFixture(fd3);

      //The bar
      bd->position.Set(10,15);	/**< another side of pulley system - a rectangle bar */
      fd1->density = 34.0;	  /**< density of rectangle bar is 34  */
/**< high density to balance the large box on other side */
      b2Body* box2 = m_world->CreateBody(bd);
      box2->CreateFixture(fd1);

      // The pulley joint

	//! The pulley joints(a part of pulley system) -------------------------------------------------------------------------------------------\n
    
      b2PulleyJointDef* myjoint = new b2PulleyJointDef();
      b2Vec2 worldAnchorOnBody1(-10, 15); /**< Anchor point on body 1 in world axis at (-10,15) */
      b2Vec2 worldAnchorOnBody2(10, 15); /**< Anchor point on body 2 in world axis at (10,15) */
      b2Vec2 worldAnchorGround1(-10, 20); /**< Anchor point for ground 1 in world axis at (-10,20) */
      b2Vec2 worldAnchorGround2(10, 20); /**< Anchor point for ground 2 in world axis at (10,20) */
      float32 ratio = 1.0f; // Define ratio
      myjoint->Initialize(box1, box2, worldAnchorGround1, worldAnchorGround2, box1->GetWorldCenter(), box2->GetWorldCenter(), ratio);
      m_world->CreateJoint(myjoint);
    }

    //The revolving horizontal platform
	//! **************************************************************************************************************************************\n
	//! The revolving horizontal plateform ---------------------------------------------------------------------------------------------------\n
    //! This horizontal plateform is hit on one side by the right side bar of the pulley system. \n
    //! This hit provides a rotational motion in the horizontal plateform about anchor.\n
   

    {
      b2PolygonShape shape;		/**< polygon shaped */
      shape.SetAsBox(2.2f, 0.2f);		/**< rectangle plateform of size 2.2 * 0.2 */
	
      b2BodyDef bd;
      bd.position.Set(14.0f, 14.0f);	/**< horizontal plateform positioned at (14.0,14.0) */
      bd.type = b2_dynamicBody;			/**< horizontal plateform defined as a dynamic body */
      b2Body* body = m_world->CreateBody(&bd);
      b2FixtureDef *fd = new b2FixtureDef;
      fd->density = 1.f;		/**< density of horizontal plateform is 1 */
      fd->shape = new b2PolygonShape;
      fd->shape = &shape;
      body->CreateFixture(fd);

      b2PolygonShape shape2;
      shape2.SetAsBox(0.2f, 2.0f);
      b2BodyDef bd2;
      bd2.position.Set(14.0f, 16.0f);
      b2Body* body2 = m_world->CreateBody(&bd2);

      b2RevoluteJointDef jointDef;		/**< joint of type revolute joint */
      jointDef.bodyA = body;
      jointDef.bodyB = body2;
      jointDef.localAnchorA.Set(0,0);	/**< local anchor for first body set at (0,0) */
      jointDef.localAnchorB.Set(0,0);	/**< local anchor for second body set at (0,0) */
      jointDef.collideConnected = false;
      m_world->CreateJoint(&jointDef);
    }

    //The heavy sphere on the platform
	//! **************************************************************************************************************************************\n
	//! The heavy sphere on the platform -----------------------------------------------------------------------------------------------------\n
    //! There is a heavy sphere kept on the horizontal plateform.\n
    //! When the plateform is hit the sphere falls on the plank below and causes the disturbance.\n
    

    {
      b2Body* sbody;
      b2CircleShape circle;
      circle.m_radius = 1.0;	/**< sphere of radius 1.0 */
	
      b2FixtureDef ballfd;
      ballfd.shape = &circle;
      ballfd.density = 50.0f;	/**< sphere of high density 50.0 */
      ballfd.friction = 0.0f;	/**< friction of sphere 0.0 */
      ballfd.restitution = 0.0f;	/**< coeffcient of restitution of sphere 0.0 */
      b2BodyDef ballbd;
      ballbd.type = b2_dynamicBody;	/**< sphere set as a dynamic body */
      ballbd.position.Set(14.0f, 18.0f);	/**< sphere positioned at (14.0,18.0) */
      sbody = m_world->CreateBody(&ballbd);
      sbody->CreateFixture(&ballfd);
    }


    //The see-saw system at the bottom
   	//! **************************************************************************************************************************************\n
	//! The sea-saw system on the platform ---------------------------------------------------------------------------------------------------\n
    //! The sea-saw system consist of plateform which rest on a triangular wedge.\n
    

    {
      //The triangle wedge
    
	//! the triangle wedge -------------------------------------------------------------------------------------------------------------------\n
    //! The triangular wedge is present below the plank at its middle. \n
    //! The sea-saw can rotate left or right about this point.\n
    

      b2Body* sbody;
      b2PolygonShape poly;
      b2Vec2 vertices[3];
      vertices[0].Set(-1,0);	/**< first vertex set at (-1,0) */
      vertices[1].Set(1,0);	/**< second vertex set at (1,0) */
      vertices[2].Set(0,1.5);	/**< third vertex set at (0,1.5) */
      poly.Set(vertices, 3);
      b2FixtureDef wedgefd;
      wedgefd.shape = &poly;
      wedgefd.density = 10.0f;	
      wedgefd.friction = 0.0f;
      wedgefd.restitution = 0.0f;
      b2BodyDef wedgebd;
      wedgebd.position.Set(10.0f, 0.0f);            /**< initailly wedge position set at (30.0, 0.0) */
													/**< later modified for lab 3(b): wedge position set at (10.0, 0.0) */
      sbody = m_world->CreateBody(&wedgebd);
      sbody->CreateFixture(&wedgefd);

      //The plank on top of the wedge

	//! The plank on top of the wedge --------------------------------------------------------------------------------------------------------\n
    //! On this plank which is kept on triangular wedge a light box rests. \n
    

      b2PolygonShape shape;
      shape.SetAsBox(15.0f, 0.2f);		/**< rectangle shaped plank of size 15 * 0.2 */
      b2BodyDef bd2;
      bd2.position.Set(10.0f, 1.5f);            /**< initially plank positioned at (30.0, 1.5) */
												/**< later modified for lab 3(b): plank positioned at (10.0, 1.5) */
      bd2.type = b2_dynamicBody;			/**< plank is adynamic body */
      b2Body* body = m_world->CreateBody(&bd2);
      b2FixtureDef *fd2 = new b2FixtureDef;
      fd2->density = 1.f;
      fd2->shape = new b2PolygonShape;
      fd2->shape = &shape;
      body->CreateFixture(fd2);

      b2RevoluteJointDef jd;		/**< revolute joint between plank and the tiangular wedge */
      b2Vec2 anchor;
      anchor.Set(10.0f, 1.5f);              /**< initially anchor set at (30.0, 1.5) */
											/**< late modified for lab 3(b): anchor set at (10.0, 1.5) */
      jd.Initialize(sbody, body, anchor);
      m_world->CreateJoint(&jd);

      //The light box on the right side of the see-saw
	
    //! The light box on the right side of the see-saw ---------------------------------------------------------------------------------------\n
    //! Finally the motion is passed on to this light box on the sea-saw plank. \n
    //! This box move to right after being hit.\n
    
      b2PolygonShape shape2;
      shape2.SetAsBox(2.0f, 2.0f);		/**< light box of size 2 * 2 */
      b2BodyDef bd3;
      bd3.position.Set(20.0f, 2.0f);            /**< initially light box positioned at (40.0, 2.0) */
											/**< later modified for lab 3(b): light box positioned at (40.0, 2.0) */
      bd3.type = b2_dynamicBody;
      b2Body* body3 = m_world->CreateBody(&bd3);
      b2FixtureDef *fd3 = new b2FixtureDef;
      fd3->density = 0.01f;			/**< density of box is 0.01: light */
      fd3->shape = new b2PolygonShape;
      fd3->shape = &shape2;
      body3->CreateFixture(fd3);
    }
//The see-saw system at the bottom
    //The newly added see-saw system at the bottom
   	//! **************************************************************************************************************************************\n
	//! The sea-saw system on the platform ---------------------------------------------------------------------------------------------------\n
    //! The sea-saw system consist of plateform which rest on a triangular wedge.\n
    
    {
      //The triangle wedge
//! the triangle wedge -------------------------------------------------------------------------------------------------------------------\n
    //! The triangular wedge is present below the plank at its middle. \n
    //! The sea-saw can rotate left or right about this point.\n
    
      b2Body* sbody;
      b2PolygonShape poly;
      b2Vec2 vertices[3];
      vertices[0].Set(-1,0);		/**< first vertex set at (-1,0) */
      vertices[1].Set(1,0);		/**< second vertex set at (1,0) */
      vertices[2].Set(0,1.5);		/**< third vertex set at (0,1.5) */
      poly.Set(vertices, 3);
      b2FixtureDef wedgefd;
      wedgefd.shape = &poly;
      wedgefd.density = 10.0f;
      wedgefd.friction = 0.0f;
      wedgefd.restitution = 0.0f;
      b2BodyDef wedgebd;
      wedgebd.position.Set(40.0f, 0.0f);            /**< wedge position set at (40.0, 0.0) */
      sbody = m_world->CreateBody(&wedgebd);
      sbody->CreateFixture(&wedgefd);

      //The plank on top of the wedge
//! The plank on top of the wedge --------------------------------------------------------------------------------------------------------\n
    //! On this plank which is kept on triangular wedge a light box rests. \n
      b2PolygonShape shape;
      shape.SetAsBox(15.0f, 0.2f);		/**< rectangle shaped plank of size 15 * 0.2 */
      b2BodyDef bd2;
      bd2.position.Set(40.0f, 1.5f);            /**< plank positioned at (40.0, 1.5) */
      bd2.type = b2_dynamicBody;
      b2Body* body = m_world->CreateBody(&bd2);
      b2FixtureDef *fd2 = new b2FixtureDef;
      fd2->density = 1.f;
      fd2->shape = new b2PolygonShape;
      fd2->shape = &shape;
      body->CreateFixture(fd2);

      b2RevoluteJointDef jd;
      b2Vec2 anchor;
      anchor.Set(40.0f, 1.5f);              /**< anchor positioned at (40.0, 1.5) */
      jd.Initialize(sbody, body, anchor);
      m_world->CreateJoint(&jd);

      //The light box on the right side of the see-saw
      b2PolygonShape shape2;
      shape2.SetAsBox(2.0f, 2.0f);
      b2BodyDef bd3;
      bd3.position.Set(50.0f, 2.0f);            //initially bd3.position.Set(40.0f, 2.0f);
      bd3.type = b2_dynamicBody;
      b2Body* body3 = m_world->CreateBody(&bd3);
      b2FixtureDef *fd3 = new b2FixtureDef;
      fd3->density = 0.01f;
      fd3->shape = new b2PolygonShape;
      fd3->shape = &shape2;
      body3->CreateFixture(fd3);
    }

  }

  sim_t *sim = new sim_t("Dominos", dominos_t::create);
}
