CS 251
GROUP 19
LAB01 INLAB
(Naveen Kumar, 140050013) (Yathansh Kathuria, 140050021) (Rajat Chaturvedi, 140050027)

Honour code

I pledge on my honour that I have not given or received any unauthorized assistance on this assignment.
											-Naveen Kumar
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment.
		                                				   -Yathansh Kathuria
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment.
										     -Rajat Chaturvedi

percentage work
Naveen Kumar(140050013): 100%
Yathansh Kathuria(140050021): 100%
Rajat Chaturvedi(140050027): 100%

Instructions:
1)To run from ubuntu terminal, follow these steps:
	cd [folderdirectory]
	octave [filename.m]
2)To run from octave, follow these steps:
	cd [folderdirectory]
	[filename]
3)Follow the onscreen instruction to calculate the 12th root of 2.

4)Press 1 to exit the program.

5)Press 2 to continue to calculate the nth root of any POSITIVE number.  

Citations :
1) www.gnu.org/software/octave
2) octave.sourceforge.net	
3) piazza.com

Thanks to the Professor and the TAs for their guidance and help.

