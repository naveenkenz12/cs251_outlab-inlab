format rat;
x0=input("give the standard value of root to start from.\n");
i=0;

if(x0==0)					%to avoid division by 0 in case of bad input 
	x0=x0+0.01;
endif
A(1)=x0;
while(abs(x0^12-2)>=0.0000000000001)		%implementing a particular case of Newton-Raphson method
	x0=(1/12)*(11*x0+2/(x0^11));
	i=i+1;	
	A(i+1)=x0;			        %forming an array to later plot the graph
endwhile

format free;
printf("The real 12th roots of 2 are: \n 1.  %.10f \n 2. %.10f\n",x0,-x0)       
						%there are only two real 12th roots of 2 
clf;
j=1:1:i+1;
line(j-1,A(j))					%code for graph, labels and legend
xlabel ("k");
ylabel ("x(k) ->");
title("graph of x(k) vs k ->");
legend("x(k)");


c=input("press 1 to exit or 2 to continue:");   %code to get nth root of any positive number
if(c==1)
	exit;
elseif(c==2)
	format rat;
	a=input("Enter the number whose nth root is to be determined (only positive number): \n");
	n=input("Enter the value of n (only positive integer): \n");
	x0=1;
	while(abs(x0^n-a)>=0.00000001)		
		x0=(1/n)*((n-1)*x0+a/(x0^(n-1)));
	endwhile
	format free;
	if(mod(n,2)==0)					%if n is even there are 2 real roots
		printf("The real %dth roots of %f are: \n 1.  %.5f \n 2. %.5f\n",n,a,x0,-x0)
	else 						%if n is odd there is only 1 real root
		printf("The real %dth root of %f is: \n   %.5f\n",n,a,x0)    
	endif
endif
   

